//
//  ViewController.h
//  Chomp
//
//  Created by Ileana Palesi on 10/26/18.
//  Copyright © 2018 Iona. All rights reserved.
//
/*
apple images from http://www.dff.com.tr/, https://commons.wikimedia.org/wiki/File:Single_apple.png,
 https://purepng.com/photo/13961/food-red-apple, and https://www.dabur.com/realfruitpower/fruit-juices/apple-fruit-history
music and backgrounds from https://soundimage.org/looping-music/
sound effect from http://soundbible.com/1968-Apple-Bite.html
 */

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "SecondViewController.h"
#import "AudioController.h"
#import "ViewControllerDelegate.h"

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height

@interface ViewController : UIViewController <ViewControllerDelegate, UINavigationControllerDelegate>
{
    IBOutlet UILabel *textLabel1;
    IBOutlet UILabel *textLabel2;
    IBOutlet UIButton *playButton;
    SecondViewController *secondView;
    AudioController *audioController;
}
@property(strong, nonatomic) IBOutlet UILabel *textLabel1;
@property(strong, nonatomic) IBOutlet UILabel *textLabel2;
@property(strong, nonatomic) IBOutlet UIButton *playButton;
@property (strong, nonatomic) AudioController *audioController;

- (void) cleanup;
- (IBAction)buttonPressed:(id)sender;

@end

