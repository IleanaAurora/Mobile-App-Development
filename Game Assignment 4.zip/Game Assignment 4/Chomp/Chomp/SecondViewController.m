//
//  SecondViewController.m
//  Chomp
//
//  Created by Ileana Palesi on 10/26/18.
//  Copyright © 2018 Iona. All rights reserved.
//

//https://freakycoder.com/ios-notes-19-how-to-push-and-present-to-viewcontroller-programmatically-how-to-switch-vc-8f8f65b55c7b

#import "SecondViewController.h"
#import "Foundation/Foundation.h"

@interface SecondViewController ()

@end

@implementation SecondViewController
@synthesize images, apple_1, apple_2, apple_3, apple_4, apple_5, apple_6, apple_7, apple_8, apple_9, fromLabel, seconds;

- (id) initWithDelegate:(id)del
{
    if (self = [super init])
    {
        delegate = del;
        UIImageView *imageView= [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frameWidth, frameHeight)];
        imageView.image = [UIImage imageNamed: [NSString stringWithFormat:@"leaves.jpg"]];
        [self.view addSubview:imageView];
        
        srand((unsigned int)time(NULL));
        images = [[NSArray alloc] initWithObjects:
                  [UIImage imageNamed:@"apple_1.png"],
                  [UIImage imageNamed:@"apple_2.png"],
                  [UIImage imageNamed:@"apple_3.png"],
                  [UIImage imageNamed:@"apple_4.png"],
                  nil];
        apple_1 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_2 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_3 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_4 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_5 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_6 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_7 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_8 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];
        apple_9 = [[UIImageView alloc] initWithFrame: CGRectMake((fmod(rand(),frameWidth)), (fmod(rand(),frameHeight)), 30, 30)];

        apple_1.animationImages = images;
        apple_1.animationDuration = 1;
        apple_1.contentMode = UIViewContentModeScaleAspectFill;
        apple_1.userInteractionEnabled = YES;
        [self.view addSubview: apple_1];
        [apple_1 startAnimating];
        
        apple_2.animationImages = images;
        apple_2.animationDuration = 1;
        apple_2.contentMode = UIViewContentModeScaleAspectFill;
        apple_2.userInteractionEnabled = YES;
        [self.view addSubview: apple_2];
        [apple_2 startAnimating];
        
        apple_3.animationImages = images;
        apple_3.animationDuration = 1;
        apple_3.contentMode = UIViewContentModeScaleAspectFill;
        apple_3.userInteractionEnabled = YES;
        [self.view addSubview: apple_3];
        [apple_3 startAnimating];
        
        apple_4.animationImages = images;
        apple_4.animationDuration = 1;
        apple_4.contentMode = UIViewContentModeScaleAspectFill;
        apple_4.userInteractionEnabled = YES;
        [self.view addSubview: apple_4];
        [apple_4 startAnimating];
        
        apple_5.animationImages = images;
        apple_5.animationDuration = 1;
        apple_5.contentMode = UIViewContentModeScaleAspectFill;
        apple_5.userInteractionEnabled = YES;
        [self.view addSubview: apple_5];
        [apple_5 startAnimating];
        
        apple_6.animationImages = images;
        apple_6.animationDuration = 1;
        apple_6.contentMode = UIViewContentModeScaleAspectFill;
        apple_6.userInteractionEnabled = YES;
        [self.view addSubview: apple_6];
        [apple_6 startAnimating];
        
        apple_7.animationImages = images;
        apple_7.animationDuration = 1;
        apple_7.contentMode = UIViewContentModeScaleAspectFill;
        apple_7.userInteractionEnabled = YES;
        [self.view addSubview: apple_7];
        [apple_7 startAnimating];
        
        apple_8.animationImages = images;
        apple_8.animationDuration = 1;
        apple_8.contentMode = UIViewContentModeScaleAspectFill;
        apple_8.userInteractionEnabled = YES;
        [self.view addSubview: apple_8];
        [apple_8 startAnimating];
        
        apple_9.animationImages = images;
        apple_9.animationDuration = 1;
        apple_9.contentMode = UIViewContentModeScaleAspectFill;
        apple_9.userInteractionEnabled = YES;
        [self.view addSubview: apple_9];
        [apple_9 startAnimating];
        
        seconds = 7;
        UIFont *customFont = [UIFont fontWithName:@"MarkerFelt-Wide" size:25]; //custom font
        NSString *text = [NSString stringWithFormat:@"%02d", seconds];
        CGSize labelSize = [text sizeWithFont:customFont constrainedToSize:CGSizeMake(40, 20) lineBreakMode:NSLineBreakByTruncatingTail];
        fromLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, labelSize.width, labelSize.height)];
        fromLabel.text = text;
        fromLabel.font = customFont;
        fromLabel.adjustsFontSizeToFitWidth = YES;
        fromLabel.adjustsLetterSpacingToFitWidth = YES;
        fromLabel.backgroundColor = [UIColor grayColor];
        fromLabel.textColor = [UIColor whiteColor];
        fromLabel.textAlignment = NSTextAlignmentLeft;
        [self.view addSubview:fromLabel];
        
        _timer = [self createTimer];
        
        NSURL *fileURL = [[NSBundle mainBundle] URLForResource: @"apple_bite.wav" withExtension:nil];
        if (fileURL)
        {
            AudioServicesCreateSystemSoundID((__bridge CFURLRef)fileURL, &bite);
        }
    }
    return self;
}

- (NSTimer *)createTimer
{
    return [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerTicked:) userInfo:nil repeats:YES];
}

- (void)timerTicked:(NSTimer *)timer
{
    if(seconds>0)
    {
        [fromLabel setText:[NSString stringWithFormat:@"%02d", seconds]];
        seconds-=1;
        NSLog(@"%d", seconds);
        if((apple_1.hidden == YES) && (apple_2.hidden == YES) && (apple_3.hidden == YES) && (apple_4.hidden == YES) && (apple_5.hidden == YES) && (apple_6.hidden == YES) && (apple_7.hidden == YES) && (apple_8.hidden == YES) && (apple_9.hidden == YES))
            {_won = YES;}
        if(_won == YES)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"YOU CHOMPED ALL THE APPLES" message:@"Congrats, You Win!" delegate:nil cancelButtonTitle:@"YAY!" otherButtonTitles:nil];
            [alert show];
            [timer invalidate];
            [self gameDidFinish];
        }
    }
    else if(seconds == 0)
    {
        [fromLabel setText:[NSString stringWithFormat:@"%02d", seconds]];
        NSLog(@"%d", seconds);
        //[timer invalidate];
        //[self gameDidFinish];
        if((apple_1.hidden == NO) || (apple_2.hidden == NO) || (apple_3.hidden == NO) || (apple_4.hidden == NO) || (apple_5.hidden == NO) || (apple_6.hidden == NO) || (apple_7.hidden == NO) || (apple_8.hidden == NO) || (apple_9.hidden == NO))
           {_won = NO;}
        if(_won == NO)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"TIME'S UP" message:@"Sorry, You Lost!" delegate:nil cancelButtonTitle:@"OK..." otherButtonTitles:nil];
            [alert show];
            [timer invalidate];
            [self gameDidFinish];
        }
    }
}

- (void) navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)vController animated:(BOOL)animated
{
    [vController viewWillAppear:animated];
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden: YES];
    
}

- (void) gameDidFinish
{
    [[self navigationController] popViewControllerAnimated:YES];
    [delegate cleanup];
}

- (void) touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    if(touch.view == apple_1)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_1.hidden = YES;
    }
    if(touch.view == apple_2)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_2.hidden = YES;
    }
    if(touch.view == apple_3)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_3.hidden = YES;
    }
    if(touch.view == apple_4)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_4.hidden = YES;
    }
    if(touch.view == apple_5)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_5.hidden = YES;
    }
    if(touch.view == apple_6)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_6.hidden = YES;
    }
    if(touch.view == apple_7)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_7.hidden = YES;
    }
    if(touch.view == apple_8)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_8.hidden = YES;
    }
    if(touch.view == apple_9)
    {
        AudioServicesPlaySystemSoundWithCompletion(bite, ^{  });
        apple_9.hidden = YES;
    }
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    apple_1 = nil;
    apple_2 = nil;
    apple_3 = nil;
    apple_4 = nil;
    apple_5 = nil;
    apple_6 = nil;
    apple_7 = nil;
    apple_8 = nil;
    apple_9 = nil;
    AudioServicesDisposeSystemSoundID(bite);
}

@end
