//
//  ViewControllerDelegate.h
//  Chomp
//
//  Created by Ileana Palesi on 10/29/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ViewControllerDelegate <NSObject>
@optional
- (void) cleanup;
@end
