//
//  AudioController.h
//  Chomp
//
//  Created by Ileana Palesi on 11/2/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <Foundation/Foundation.h>
@import AVFoundation;

@interface AudioController : NSObject <AVAudioPlayerDelegate>
{
    AVAudioSession *audioSession;
    AVAudioPlayer *music;
}

@property (strong, nonatomic) AVAudioSession *audioSession;
@property (strong, nonatomic) AVAudioPlayer *music;
@property (assign) BOOL playing;

- (void) play;

@end
