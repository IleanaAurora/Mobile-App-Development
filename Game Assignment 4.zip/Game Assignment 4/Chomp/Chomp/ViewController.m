//
//  ViewController.m
//  Chomp
//
//  Created by Ileana Palesi on 10/26/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize textLabel1, textLabel2, playButton, audioController;

- (void) viewDidLoad{
    [super viewDidLoad];
    audioController = [[AudioController alloc] init];
    [audioController play];
    UIImageView *img = [[UIImageView alloc] initWithImage:[UIImage imageNamed:[NSString stringWithFormat: @"menu_background.jpg"]]];
    img.userInteractionEnabled = NO;
    [self.view addSubview:img];
    [[img superview] sendSubviewToBack:img];
    textLabel1.text=[NSString stringWithFormat:@"Welcome to Chomp!"];
    textLabel2.text=[NSString stringWithFormat:@"You will have 7 seconds to\nfind and chomp all 9 apples.\nIf the timer runs out before\nyou can chomp all 9 apples,\nyou lose.\nOtherwise, you win!\nWhen you're ready to play,\njust press \"Play\".\nHappy playing!"];
    [playButton setTitle:@"Play" forState:UIControlStateNormal];
    [playButton addTarget: self action:@selector(showView) forControlEvents: UIControlEventTouchDown];
}

- (void) navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)vController animated:(BOOL)animated
{
    [vController viewWillAppear:animated];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden: YES];
    
}

- (void) showView
{
    secondView = [[SecondViewController alloc] initWithDelegate: self];
    [self.navigationController pushViewController: secondView animated: YES];
}

- (void) cleanup;
{
    [self.navigationController popViewControllerAnimated: YES];
    secondView = nil;
}

- (IBAction)buttonPressed:(id)sender {
    [self performSegueWithIdentifier: @"mySegue" sender: nil];
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
