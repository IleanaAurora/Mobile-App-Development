//
//  AudioController.m
//  Chomp
//
//  Created by Ileana Palesi on 11/2/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import "AudioController.h"

@interface AudioController ()

@end

@implementation AudioController
@ synthesize audioSession, music, playing;

- (id)init
{
    self = [super init];
    if (self) {
        [self configureAudioSession];
        [self configureAudioMusic];
    }
    return self;
}

- (void) configureAudioSession
{
    audioSession = [AVAudioSession sharedInstance];
    [audioSession setCategory: AVAudioSessionCategoryAmbient error: nil ];
}

- (void)configureAudioMusic
{
    NSString *path = [[NSBundle mainBundle] pathForResource: @"Good-Morning-Doctor-Weird" ofType: @"mp3"];
    NSURL *URL = [NSURL fileURLWithPath: path];
    music = [[AVAudioPlayer alloc] initWithContentsOfURL: URL error:nil];
    music.delegate = self;
    music.numberOfLoops = -1;
}

- (void) play
{
    if (playing || [audioSession isOtherAudioPlaying]) return;
    [music prepareToPlay];
    [music play];
    playing = YES;
}

@end
