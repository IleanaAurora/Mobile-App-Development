//
//  SecondViewController.h
//  Chomp
//
//  Created by Ileana Palesi on 10/26/18.
//  Copyright © 2018 Iona. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "AudioController.h"
#import "ViewControllerDelegate.h"

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height

@interface SecondViewController : UIViewController
{
    NSArray *images;
    SystemSoundID bite;
    UIImageView *apple_1;
    UIImageView *apple_2;
    UIImageView *apple_3;
    UIImageView *apple_4;
    UIImageView *apple_5;
    UIImageView *apple_6;
    UIImageView *apple_7;
    UIImageView *apple_8;
    UIImageView *apple_9;
    __weak NSObject<ViewControllerDelegate> *delegate;
    UILabel *fromLabel;
}

@property(nonatomic, retain) NSArray *images;
@property(nonatomic, retain) UIImageView *apple_1;
@property(nonatomic, retain) UIImageView *apple_2;
@property(nonatomic, retain) UIImageView *apple_3;
@property(nonatomic, retain) UIImageView *apple_4;
@property(nonatomic, retain) UIImageView *apple_5;
@property(nonatomic, retain) UIImageView *apple_6;
@property(nonatomic, retain) UIImageView *apple_7;
@property(nonatomic, retain) UIImageView *apple_8;
@property(nonatomic, retain) UIImageView *apple_9;
@property (nonatomic, retain) UILabel *fromLabel;
//@property (weak, nonatomic) UILabel *fromLabel;
@property (weak, nonatomic) NSTimer *timer;
@property (assign) BOOL won;
@property int seconds;

- (id) initWithDelegate:(id)pDel;

@end
