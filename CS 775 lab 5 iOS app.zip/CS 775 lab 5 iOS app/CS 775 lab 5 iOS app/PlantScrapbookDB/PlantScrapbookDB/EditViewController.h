//
//  EditViewController.h
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Plant.h"

@interface EditViewController : UIViewController <UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    UILabel *lbl1, *lbl2;
    UITextField *itemName;
    UITextField *itemDescrip;
    UIImageView *itemPic;
    UIButton *done, *picBtn;
    Plant *item;
}

@property(nonatomic, strong) UILabel *lbl1, *lbl2;
@property(nonatomic, strong) UIButton *done;
@property(nonatomic, strong) UITextField *itemName;
@property(nonatomic, strong) UITextField *itemDescrip;
@property(nonatomic, strong) UIImageView *itemPic;
@property(nonatomic, strong) Plant *item;

@end
