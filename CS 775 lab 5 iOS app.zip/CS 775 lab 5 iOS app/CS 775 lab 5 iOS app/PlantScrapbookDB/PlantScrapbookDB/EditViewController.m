//
//  EditViewController.m
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//

#import "EditViewController.h"
#import "Plant.h"

#define frameWidth self.view.frame.size.width
#define frameHeight self.view.frame.size.height

@implementation EditViewController
@synthesize lbl1, lbl2;
@synthesize itemName;
@synthesize itemDescrip;
@synthesize itemPic;
@synthesize done;
@synthesize item;


- (id) init
{
    if (self = [super init])
    {
        self.view.backgroundColor = [UIColor colorWithRed: .5 green: .95 blue: .65 alpha: 1.0];
        
        lbl1 = [[UILabel alloc] initWithFrame: CGRectMake(10, 70, 100, 30)];
        lbl1.text = @"Plant Name";
        lbl1.font = [UIFont fontWithName: @"Helvetica" size: 19];
        lbl1.textColor = [UIColor blueColor];
        [self.view addSubview: lbl1];
        
        itemName = [[UITextField alloc] initWithFrame: CGRectMake(120, 70, frameWidth*.5, 30)];
        itemName.borderStyle = UITextBorderStyleRoundedRect;
        itemName.textColor = [UIColor blueColor];
        itemName.delegate = self;
        [self.view addSubview: itemName];
        
        
        lbl2 = [[UILabel alloc] initWithFrame: CGRectMake(10, 140, 100, 30)];
        lbl2.text = @"Description";
        lbl2.font = [UIFont fontWithName: @"Helvetica" size: 19];
        lbl2.textColor = [UIColor blueColor];
        [self.view addSubview: lbl2];
        
        itemDescrip = [[UITextField alloc] initWithFrame: CGRectMake(120, 140, frameWidth*.5, 30)];
        itemDescrip.borderStyle = UITextBorderStyleRoundedRect;
        itemDescrip.textColor = [UIColor blueColor];
        itemDescrip.delegate = self;
        [self.view addSubview: itemDescrip];
        
        itemPic = [[UIImageView alloc] initWithFrame: CGRectMake(0, 0, 200, 200)];
        itemPic.center = CGPointMake(frameWidth/2.0, frameHeight/2.0);
        [self.view addSubview: itemPic];
        
        
        picBtn = [UIButton buttonWithType: UIButtonTypeRoundedRect];
        picBtn.frame = CGRectMake(0, 0, 120, 40);
        picBtn.center = CGPointMake(frameWidth/2.0, frameHeight - 100);
        picBtn.opaque = YES;
        picBtn.layer.cornerRadius = 12;
        picBtn.clipsToBounds = YES;
        picBtn.backgroundColor = [UIColor blueColor];
        picBtn.tintColor = [UIColor whiteColor];
        [picBtn setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [picBtn.titleLabel setFont:[UIFont systemFontOfSize: 22]];
        [picBtn setTitle:@"Picture" forState:UIControlStateNormal];
        [picBtn addTarget:self action:@selector(takePhoto:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview: picBtn];
        
        
        done = [UIButton buttonWithType: UIButtonTypeRoundedRect];
        done.frame = CGRectMake(0, 0, 120, 40);
        done.center = CGPointMake(frameWidth/2.0, frameHeight - 50);
        done.opaque = YES;
        done.layer.cornerRadius = 12;
        done.clipsToBounds = YES;
        done.backgroundColor = [UIColor blueColor];
        done.tintColor = [UIColor whiteColor];
        [done setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [done.titleLabel setFont:[UIFont systemFontOfSize: 22]];
        [done setTitle:@"Done" forState:UIControlStateNormal];
        [done addTarget:self action:@selector(finishedEditing) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview: done];
        
    }
    
    return self;
}


- (void) finishedEditing
{
    [self viewWillDisappear: YES];
}



- (void) viewWillAppear: (BOOL) animated
{
    [super viewWillAppear: animated];
    itemName.text = item.name;
    itemDescrip.text = item.pDescription;
    itemPic.image = [self getImage];
}



- (void)viewWillDisappear:(BOOL)animated
{
    item.name = itemName.text;
    item.pDescription = itemDescrip.text;
    NSManagedObjectContext *context = item.managedObjectContext;
    NSError *error = nil;
    [context save: &error];
    [self.navigationController popViewControllerAnimated: YES];
    [super viewWillDisappear: YES];
}



- (void) textFieldDidEndEditing: (UITextField *) txtField
{
    if (txtField == itemName)
        item.name = txtField.text;
    else if (txtField == itemDescrip)
        item.pDescription = txtField.text;
}



- (BOOL) textFieldShouldReturn: (UITextField *) txtField {
    [txtField resignFirstResponder];
    return YES;
}



- (void) takePhoto:(UIButton *)sender
{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"Error"
                                                              message:@"Device has no camera"
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles: nil];
        [myAlertView show];
    }
    else
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType: UIImagePickerControllerSourceTypeCamera];
        picker.delegate = self;
        picker.allowsEditing = YES;
        
        [self presentViewController: picker animated: YES completion: NULL];
    }
}



#pragma mark - Image Picker Controller delegate methods

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    UIImage *img = (UIImage *) [info objectForKey: UIImagePickerControllerEditedImage];
    itemPic.image = img;
    
    NSData* imgData = UIImageJPEGRepresentation(img, 1.0);
    
    NSArray *docsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [docsPath objectAtIndex: 0];
    NSString *loc = [NSString stringWithFormat:@"%@/%@.jpg", docsDir, item.name];
    [imgData writeToFile:loc atomically:NO];
    
    [picker dismissViewControllerAnimated: YES completion: nil];
}



- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated: YES completion: nil];
}



- (UIImage *) getImage
{
    NSArray *docsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [docsPath objectAtIndex: 0];
    NSString *loc = [NSString stringWithFormat:@"%@/%@.jpg", docsDir, item.name];
    return [UIImage imageWithContentsOfFile: loc];
}
@end

