//
//  Plant.h
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//

#import <CoreData/CoreData.h>


@interface Plant :  NSManagedObject
{
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *pDescription;

@end
