//
//  ViewController.m
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//
//plant-icon taken from: https://cognigen-cellular.com/explore/plant-clipart/
//flower icon taken from: http://worldartsme.com/flower-potted-plant-clipart.html#gal_post_53585_flower-potted-plant-clipart-1.jpg

#import "RootViewController.h"
#import "Plant.h"

@implementation RootViewController
@synthesize menuItems;
@synthesize managedObjectContext;
@synthesize editViewCtrl;
@synthesize tableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Plant Scrapbook";
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemAdd target:self action:@selector(addItem)];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName: @"Plant" inManagedObjectContext: managedObjectContext];
    request.entity = entity;
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey: @"name" ascending: YES];
    NSArray *sortDescriptors = [NSArray arrayWithObjects: sortDescriptor, nil];
    request.sortDescriptors = sortDescriptors;
    NSError *error = nil;
    menuItems = [[managedObjectContext executeFetchRequest: request error: &error] mutableCopy];
    
    editViewCtrl = [[EditViewController alloc] init];
    
    // init table view
    tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    // must set delegate & dataSource, otherwise the the table will be empty and not responsive
    tableView.delegate = self;
    tableView.dataSource = self;
    
    tableView.backgroundColor = [UIColor greenColor];
    
    // add to canvas
    [self.view addSubview:tableView];
}

- (void) addItem
{
    Plant *item = [NSEntityDescription insertNewObjectForEntityForName: @"Plant" inManagedObjectContext: managedObjectContext];
    NSError *error = nil;
    [managedObjectContext save: &error];
    
    [menuItems insertObject: item atIndex: 0];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow: 0 inSection: 0];
    [self.tableView insertRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation: UITableViewRowAnimationFade];
}



- (void) viewWillAppear: (BOOL) animated
{
    [super viewWillAppear: animated];
    if(editViewCtrl.item)
    {
        NSIndexPath *path = [NSIndexPath indexPathForRow: [menuItems indexOfObject: editViewCtrl.item] inSection: 0];
        NSArray *paths = [NSArray arrayWithObjects: path, nil];
        [self.tableView reloadRowsAtIndexPaths: paths withRowAnimation: NO];
        editViewCtrl.item = nil;
    }
}



#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return menuItems.count;
}


- (UITableViewCell *)tableView: (UITableView *) tableView cellForRowAtIndexPath: (NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: CellIdentifier];
    
    Plant *item = [menuItems objectAtIndex: indexPath.row];
    if (item.name == nil)
        cell.textLabel.text = @"New Item";
    else
        cell.textLabel.text = item.name; //[NSString stringWithFormat:@"%@", menuItem.name];
    
    cell.textLabel.font = [UIFont fontWithName: @"Helvetica-Bold" size: 14];
    cell.textLabel.textColor = [UIColor blueColor];
    cell.textLabel.highlightedTextColor = [UIColor yellowColor];
    cell.imageView.image = [UIImage imageNamed: @"plant-icon.png"];
    
    return cell;
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    editViewCtrl.item = [menuItems objectAtIndex: indexPath.row];
    [self.navigationController pushViewController: editViewCtrl animated:YES];
}





- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}




- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [managedObjectContext deleteObject: [menuItems objectAtIndex: indexPath.row]];
        NSError *error = nil;
        [managedObjectContext save: &error];
        
        [menuItems removeObjectAtIndex: indexPath.row];
        
        [tableView deleteRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation: YES];
    }
}

@end
