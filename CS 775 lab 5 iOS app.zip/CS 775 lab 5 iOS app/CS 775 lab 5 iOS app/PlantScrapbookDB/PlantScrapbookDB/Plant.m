//
//  Plant.m
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//

#import "Plant.h"


@implementation Plant

@dynamic name;
@dynamic pDescription;

@end
