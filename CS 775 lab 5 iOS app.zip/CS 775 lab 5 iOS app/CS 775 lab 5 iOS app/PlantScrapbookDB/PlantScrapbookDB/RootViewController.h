//
//  ViewController.h
//  PlantScrapbookDB
//
//  Created by Palesi, Ileana on 3/28/19.
//  Copyright © 2019 Palesi, Ileana. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditViewController.h"

@interface RootViewController : UIViewController <UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *menuItems;
    NSManagedObjectContext *managedObjectContext;
    EditViewController *editViewCtrl;
    Plant *plantType;
}

@property(nonatomic, strong) NSMutableArray *menuItems;
@property(nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property(nonatomic, strong) EditViewController *editViewCtrl;
@property(nonatomic, strong) UITableView *tableView;

- (void) addItem;

@end

