//
//  FirstViewController.swift
//  FinalProject
//
//  Created by Ileana Palesi on 11/26/18.
//  Copyright © 2018 Iona. All rights reserved.
/*
icon from https://www.google.com/search?biw=990&bih=455&tbm=isch&sa=1&ei=OdgCXIufDcuijwTohrUo&q=bedtime+reading&oq=bedtime+re&gs_l=img.3.0.0l9.9115.9345..11945...0.0..0.46.87.2......1....1..gws-wiz-img.BVPqkskn9yg#imgrc=-WIB9APWqeNToM:
 
 background from https://www.google.com/search?biw=1098&bih=576&tbm=isch&sa=1&ei=798CXMyEKO3B_QaRmqiYBw&q=stars+sky+cartoon+wallapaper&oq=stars+sky+cartoon+wallapaper&gs_l=img.3...5084.8954..9073...3.0..0.46.519.12......1....1..gws-wiz-img.......0i8i30.0q-ea6n7WM4#imgrc=csWSG3fFcJTmjM:
 
 play, pause, stop, record, and record_stop icons from https://www.iconfinder.com/search/?q=pause%20stop%20play and https://www.iconfinder.com/search/?q=record
 
 record button sound effects from http://soundbible.com/tags-button.html
*/

import Foundation
import UIKit

class FirstViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet var tableView: UITableView!
    
    var stories: [Story] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background.jpg")
        backgroundImage.contentMode = UIView.ContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    
    func getData()
    {
        let dlgt = UIApplication.shared.delegate as! AppDelegate
        let context = dlgt.persistentContainer.viewContext
        
        do
        {
            stories = try context.fetch(Story.fetchRequest())
        }
        catch { print("Could not load data from the Database") }
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        getData()
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return stories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = UITableViewCell()
        
        let story = stories[indexPath.row]
        cell.backgroundColor = .clear
        cell.textLabel?.text = story.title!
        cell.textLabel?.textColor = .white
        if(story.isMom == false)
        {
            cell.imageView?.image = UIImage(named: "woman.png")
        }
        else
        {
            cell.imageView?.image = UIImage(named: "man.png")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        performSegue(withIdentifier: "editViewSegue", sender: indexPath)
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            let alert = UIAlertController(title: "Hold on there!", message: "Are you sure you want to delete the selected story?", preferredStyle: .actionSheet)
            let action1 = UIAlertAction(title: "YES", style: .default, handler: { (action1) in deleteStory()})
            let action2 = UIAlertAction(title: "NO", style: .default, handler: nil)
            alert.addAction(action1)
            alert.addAction(action2)
            present(alert, animated: true, completion:nil)
    }
        
    func deleteStory()
    {
        let dlgt = UIApplication.shared.delegate as! AppDelegate
        let context = dlgt.persistentContainer.viewContext
        let story = stories[indexPath.row]
        context.delete(story)
        dlgt.saveContext()
        
        do
        {
            stories = try context.fetch(Story.fetchRequest())
        }
        catch { print("Could not load data from the Database") }
        
        tableView.reloadData()
    }
    }
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "editViewSegue"
        {
            let indexPath: NSIndexPath  = sender as! NSIndexPath
            let story = stories[indexPath.row]
            
            let editViewCtrl: SecondViewController = segue.destination as! SecondViewController
            editViewCtrl.stories = self.stories;
            editViewCtrl.editItem = story;
        }
    }
}

