//
//  ThirdViewController.swift
//  FinalProject
//
//  Created by Ileana Palesi on 11/30/18.
//  Copyright © 2018 Iona. All rights reserved.
//

import UIKit
import AVFoundation
import AudioToolbox

class ThirdViewController: UIViewController, AVAudioRecorderDelegate
{
    var editItem: Story?
    var stories: [Story] = []
    
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var recordBtn: UIButton!
    @IBOutlet var doneBtn: UIButton!

    
    var audioRecorder: AVAudioRecorder!
    var meterTimer:Timer!
    var isAudioRecordingGranted: Bool!
    var isRecording = false
    var mySound1: SystemSoundID = 0
    var mySound2: SystemSoundID = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background.jpg")
        backgroundImage.contentMode = UIView.ContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        check_record_permission()
        if let clickOnURL = Bundle.main.url(forResource: "clickOn", withExtension: "mp3") {
            AudioServicesCreateSystemSoundID(clickOnURL as CFURL, &mySound1)
        }
        if let clickOffURL = Bundle.main.url(forResource: "clickOff", withExtension: "mp3") {
            AudioServicesCreateSystemSoundID(clickOffURL as CFURL, &mySound2)
        }
    }
    
    func check_record_permission()
    {
        switch AVAudioSession.sharedInstance().recordPermission {
        case AVAudioSession.RecordPermission.granted:
            isAudioRecordingGranted = true
            break
        case AVAudioSession.RecordPermission.denied:
            isAudioRecordingGranted = false
            break
        case AVAudioSession.RecordPermission.undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission({ (allowed) in
                if allowed
                {
                    self.isAudioRecordingGranted = true
                }
                else
                {
                    self.isAudioRecordingGranted = false
                }
            })
            break
        default:
            break
        }
    }
    
    func getDocumentsDirectory() -> URL
    {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
    func getFileUrl() -> URL
    {
        let filename = (editItem?.title!)! + "_" + (editItem?.firstName!)! + "_" + (editItem?.lastName!)! + ".m4a"
        let filePath = getDocumentsDirectory().appendingPathComponent(filename)
        editItem?.filename = filename
        return filePath
    }
        
    
    func setup_recorder()
    {
        if isAudioRecordingGranted
        {
            let session = AVAudioSession.sharedInstance()
            do
            {
                try session.setCategory(.playAndRecord, mode:.default, options: [.defaultToSpeaker])
                try session.setActive(true)
                let settings = [
                    AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                    AVSampleRateKey: 44100,
                    AVNumberOfChannelsKey: 2,
                    AVEncoderAudioQualityKey:AVAudioQuality.high.rawValue
                ]
                audioRecorder = try AVAudioRecorder(url: getFileUrl(), settings: settings)
                audioRecorder.delegate = self
                audioRecorder.isMeteringEnabled = true
                audioRecorder.prepareToRecord()
            }
            catch let error {
                display_alert(msg_title: "Error", msg_desc: error.localizedDescription, action_title: "OK")
            }
        }
        else
        {
            display_alert(msg_title: "Error", msg_desc: "Don't have access to use your microphone.", action_title: "OK")
        }
    }
        
    
    @IBAction func start_recording(_ sender: UIButton)
    {
        if(isRecording)
        {
            finishAudioRecording(success: true)
            AudioServicesPlaySystemSound(mySound2);
            recordBtn.setImage(UIImage (named:"record.png"), for: .normal)
            isRecording = false
        }
        else
        {
            AudioServicesPlaySystemSound(mySound1);
            setup_recorder()
            audioRecorder.record()
            meterTimer = Timer.scheduledTimer(timeInterval: 0.1, target:self, selector:#selector(self.updateAudioMeter(timer:)), userInfo:nil, repeats:true)
            recordBtn.setImage(UIImage (named:"stop_record.png"), for: .normal)
            isRecording = true
        }
    }

    @objc func updateAudioMeter(timer: Timer)
    {
        if audioRecorder.isRecording
        {
            let hr = Int((audioRecorder.currentTime / 60) / 60)
            let min = Int(audioRecorder.currentTime / 60)
            let sec = Int(audioRecorder.currentTime.truncatingRemainder(dividingBy: 60))
            let totalTimeString = String(format: "%02d:%02d:%02d", hr, min, sec)
            timeLabel.text = totalTimeString
            audioRecorder.updateMeters()
        }
    }
    
    func finishAudioRecording(success: Bool)
    {
        if success
        {
            audioRecorder.stop()
            meterTimer.invalidate()
            audioRecorder = nil
        }
        else
        {
            display_alert(msg_title: "Error", msg_desc: "Recording failed.", action_title: "OK")
        }
    }
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool)
    {
        if !flag
        {
            finishAudioRecording(success: false)
        }
    }
    
    func display_alert(msg_title : String , msg_desc : String ,action_title : String)
    {
        let alert = UIAlertController(title: msg_title, message: msg_desc, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: action_title, style: .default, handler: nil))
        self.present(alert, animated: true)
    }

    @IBAction func donePressed(_ sender: Any)
    {
        if (editItem?.filename != nil)
        {
            let editViewCtrl = SecondViewController()
            editViewCtrl.editItem = self.editItem
            editViewCtrl.stories = self.stories
        }
        else
        {
            display_alert(msg_title: "Wait!", msg_desc: "You did not record a story.", action_title: "OK")
        }
        navigationController!.popViewController(animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        if(audioRecorder != nil)
        {
            finishAudioRecording(success: true)
        }
    }
    
}
