//
//  SecondViewController.swift
//  FinalProject
//
//  Created by Ileana Palesi on 11/26/18.
//  Copyright © 2018 Iona. All rights reserved.
//

import UIKit
import MediaPlayer
import AVFoundation

class SecondViewController: UIViewController, UITextFieldDelegate, MPMediaPickerControllerDelegate
{
    @IBOutlet var bookTitle: UITextField!
    @IBOutlet var fName: UITextField!
    @IBOutlet var lName: UITextField!
    @IBOutlet var MomOrDad: UISwitch!
    @IBOutlet var MomOrDadLabel: UILabel!
    
    var fNameTxt: String = "";
    var lNameTxt: String = "";
    var titleTxt: String = "";
    var MomOrDadVal: Bool = false;
    var editItem: Story?
    var stories: [Story] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background.jpg")
        backgroundImage.contentMode = UIView.ContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        self.bookTitle.delegate = self
        self.fName.delegate = self
        self.lName.delegate = self
        if (editItem != nil)
        {
            bookTitle.text = editItem?.title
            fName.text = editItem?.firstName
            lName.text = editItem?.lastName
            MomOrDad.isOn = (editItem?.isMom)!
            MomOrDadLabel.text = MomOrDad.isOn ? "Dad" : "Mom"
        }
        else
        {
            fName.text = ""
            lName.text = ""
            bookTitle.text = ""
            MomOrDad.isOn = false
            MomOrDadLabel.text = "Mom"
        }
        fNameTxt = ""
        lNameTxt = ""
        titleTxt = ""
        MomOrDadVal = false
    }
    
    @IBAction func SaveData(_ sender: UIButton)
    {
        if (CheckData())
        {
            let dlgt = UIApplication.shared.delegate as! AppDelegate
            
            if (editItem == nil)
            {
                let vcontext = dlgt.persistentContainer.viewContext
                editItem = Story(context: vcontext)
            }
            editItem?.firstName = fName.text;
            editItem?.lastName = lName.text;
            editItem?.title = bookTitle.text;
            editItem?.isMom = MomOrDad.isOn
            dlgt.saveContext()
            
            navigationController!.popViewController(animated: true)
        }
        else
        {
            let alert = UIAlertController(title: "Hold on there!", message: "Please fill out all fields in order to save your story.", preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            
            self.present(alert, animated: true)
        }
    }
    
    @IBAction func switchToggled(_ sender: UISwitch)
    {
        if (MomOrDad.isOn)
        {
            MomOrDadLabel.text = "Dad"
        }
        else
        {
            MomOrDadLabel.text = "Mom"
        }
    }
    
    
    func CheckData() -> Bool
    {
        if  (fName != nil && fName.text != "") &&
            (lName != nil && lName.text != "") &&
            (bookTitle != nil && bookTitle.text != "")
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let identifier = segue.identifier {
            switch identifier {
            case "recordSegue":
                let controller = segue.destination as! ThirdViewController
                if (CheckData())
                {
                    let dlgt = UIApplication.shared.delegate as! AppDelegate
                    
                    if (editItem == nil)
                    {
                        let vcontext = dlgt.persistentContainer.viewContext
                        editItem = Story(context: vcontext)
                    }
                    editItem?.firstName = fName.text;
                    editItem?.lastName = lName.text;
                    editItem?.title = bookTitle.text;
                    editItem?.isMom = MomOrDad.isOn
                    
                    dlgt.saveContext()
                    
                    controller.editItem = self.editItem
                    controller.stories = self.stories
                }
                else
                {
                    let alert = UIAlertController(title: "Hold on there!", message: "Please fill out all fields in order to record your story.", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
                    self.present(alert, animated: true)
                }
            case "playSegue":
                let controller = segue.destination as! FourthViewController
                if (CheckData())
                {
                    let dlgt = UIApplication.shared.delegate as! AppDelegate
                    
                    if (editItem == nil)
                    {
                        let vcontext = dlgt.persistentContainer.viewContext
                        editItem = Story(context: vcontext)
                    }
                    editItem?.firstName = fName.text;
                    editItem?.lastName = lName.text;
                    editItem?.title = bookTitle.text;
                    editItem?.isMom = MomOrDad.isOn
                    
                    dlgt.saveContext()
                    
                    controller.editItem = self.editItem
                    controller.stories = self.stories
                }
                else
                {
                    let alert = UIAlertController(title: "Hold on there!", message: "Please fill out all fields and record a story in order to play your story.", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    
                    self.present(alert, animated: true)
                }
            default:
                break
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    
}

