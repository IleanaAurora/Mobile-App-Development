//
//  FourthViewController.swift
//
//  FourthViewController.swift
//  FinalProject
//
//  Created by Ileana Palesi on 12/1/18.
//  Copyright © 2018 Iona. All rights reserved.
//

import UIKit
import AVFoundation

class FourthViewController: UIViewController, AVAudioPlayerDelegate
    
{
    var editItem: Story?
    var stories: [Story] = []
    
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet weak var timeRemainingLbl: UILabel!
    @IBOutlet var playBtn: UIButton!
    @IBOutlet var stopBtn: UIButton!
    @IBOutlet var progressBar: UIProgressView!
    @IBOutlet var volumeBtn: UISlider!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var authorLbl: UILabel!
    
    var audioPlayer : AVAudioPlayer!
    var meterTimer:Timer!
    var isPlaying = false
    var totTime: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background.jpg")
        backgroundImage.contentMode = UIView.ContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        progressBar?.progress = 0
        timeLabel.text = "00:00:00"
        if(editItem != nil)
        {
            titleLbl.text = "\"" + (editItem?.title)! + "\""
            authorLbl.text = "By " + (editItem?.firstName)! + " " + (editItem?.lastName)!
        }
        prepare_play()
    }
    
    func getDocumentsDirectory() -> URL
    {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
    func getFileUrl() -> URL
    {
        let filename = (editItem?.title!)! + "_" + (editItem?.firstName!)! + "_" + (editItem?.lastName!)! + ".m4a"
        let filePath = getDocumentsDirectory().appendingPathComponent(filename)
        editItem?.filename = filename
        return filePath
    }
    
    @objc func updateAudioMeter(timer: Timer)
    {
        if audioPlayer.isPlaying
        {
            let hr = Int((audioPlayer.currentTime / 60) / 60)
            let min = Int(audioPlayer.currentTime / 60)
            let sec = Int(audioPlayer.currentTime.truncatingRemainder(dividingBy: 60))
            let totalTimeString = String(format: "%02d:%02d:%02d", hr, min, sec)
            let hours = Int(((audioPlayer.duration-audioPlayer.currentTime) / 60) / 60)
            let mins = Int((audioPlayer.duration-audioPlayer.currentTime) / 60)
            let secs = Int((audioPlayer.duration-audioPlayer.currentTime).truncatingRemainder(dividingBy: 60))
            let timeRemainingString = String(format: "%02d:%02d:%02d", hours, mins, secs)
            progressBar.setProgress((Float(audioPlayer.currentTime/audioPlayer.duration)), animated: true)
            timeLabel.text = totalTimeString
            timeRemainingLbl.text = timeRemainingString
            audioPlayer.updateMeters()
        }
    }
    
    func prepare_play()
    {
        do
        {
            audioPlayer = try AVAudioPlayer(contentsOf: getFileUrl())
            audioPlayer.delegate = self
            progressBar.progress = 0
            audioPlayer.prepareToPlay()
            let hours = Int((audioPlayer.duration / 60) / 60)
            let mins = Int(audioPlayer.duration / 60)
            let secs = Int(audioPlayer.duration.truncatingRemainder(dividingBy: 60))
            totTime = String(format: "%02d:%02d:%02d", hours, mins, secs)
            timeRemainingLbl.text = totTime
        }
        catch{
            print("Error: audio file not found")
        }
    }
    
    @IBAction func play_recording(_ sender: Any)
    {
        if(isPlaying)
        {
            audioPlayer.pause()
            playBtn.setImage(UIImage (named:"play.png"), for: .normal)
            isPlaying = false
        }
        else
        {
            if FileManager.default.fileExists(atPath: getFileUrl().path)
            {
                playBtn.setImage(UIImage (named:"pause.png"), for: .normal)
                audioPlayer.play()
                isPlaying = true
                meterTimer = Timer.scheduledTimer(timeInterval: 0.1, target:self, selector:#selector(self.updateAudioMeter(timer:)), userInfo:nil, repeats:true)
            }
            else
            {
                display_alert(msg_title: "Error", msg_desc: "Audio file must first be recorded.", action_title: "OK")
            }
        }
    }
    
    @IBAction func stopPressed(_ sender: Any)
    {
        audioPlayer.stop()
        audioPlayer.currentTime = 0
        playBtn.setImage(UIImage (named:"play.png"), for: .normal)
        let totalTimeString = "00:00:00"
        timeLabel.text = totalTimeString
        timeRemainingLbl.text = totTime
        progressBar.progress = 0
        isPlaying = false
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool)
    {
        isPlaying = false
        playBtn.setImage(UIImage (named:"play.png"), for: .normal)
        let totalTimeString = "00:00:00"
        timeLabel.text = totalTimeString
        timeRemainingLbl.text = totTime
        progressBar.progress = 0
    }
    
    @IBAction func volumeChanged(_ sender: Any)
    {
        audioPlayer.volume = volumeBtn.value
    }
    
    func display_alert(msg_title : String , msg_desc : String ,action_title : String)
    {
        let alert = UIAlertController(title: msg_title, message: msg_desc, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: action_title, style: .default, handler: nil))
        self.present(alert, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        if(audioPlayer != nil)
        {
            audioPlayer.stop()
        }
        if(meterTimer != nil)
        {
            meterTimer.invalidate()
        }
    }
    
}


